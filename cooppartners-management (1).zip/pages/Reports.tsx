import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { generateFinancialInsight } from '../services/geminiService';
import { FileText, Download, Sparkles } from 'lucide-react';

export default function Reports() {
  const { loans, contributions, activities, members, translations } = useData();
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerateReport = async () => {
    setIsLoading(true);
    const report = await generateFinancialInsight(loans, contributions, activities, members);
    setAiReport(report);
    setIsLoading(false);
  };

  const handleExportCSV = () => {
    // Simple CSV Export Logic
    const headers = "Type,Amount,Date,Status\n";
    const contributionRows = contributions.map(c => `Contribution,${c.amount},${c.datePaid},${c.status}`).join("\n");
    const loanRows = loans.map(l => `Loan Issued,${l.principal},${l.dateIssued},${l.status}`).join("\n");
    
    const csvContent = "data:text/csv;charset=utf-8," + headers + contributionRows + "\n" + loanRows;
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "coop_financial_report.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">{translations.reports}</h2>
        <button 
          onClick={handleExportCSV}
          className="flex items-center space-x-2 text-slate-600 hover:text-blue-600 border border-slate-300 px-4 py-2 rounded-lg hover:border-blue-400 transition-all"
        >
          <Download size={18} />
          <span>Export CSV</span>
        </button>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Gemini AI Section */}
        <div className="col-span-full bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-100 rounded-2xl p-8">
           <div className="flex items-center justify-between mb-6">
             <div className="flex items-center space-x-3">
               <div className="bg-indigo-600 p-2 rounded-lg">
                 <Sparkles className="text-white" size={24} />
               </div>
               <div>
                 <h3 className="text-xl font-bold text-indigo-900">AI Financial Advisor</h3>
                 <p className="text-indigo-600 text-sm">Powered by Google Gemini 2.5 Flash</p>
               </div>
             </div>
             <button 
               onClick={handleGenerateReport}
               disabled={isLoading}
               className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 rounded-lg font-medium transition-all shadow-lg shadow-indigo-500/30 disabled:opacity-50"
             >
               {isLoading ? 'Analyzing...' : translations.aiReport}
             </button>
           </div>

           {aiReport ? (
             <div className="bg-white/80 backdrop-blur-sm p-6 rounded-xl border border-indigo-100 text-slate-700 prose prose-sm max-w-none">
               <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">{aiReport}</pre>
             </div>
           ) : (
             <div className="text-center py-8 text-indigo-400">
               Click the button above to generate an instant health check of the cooperative's finances.
             </div>
           )}
        </div>

        {/* Detailed Summary Tables */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
           <h3 className="font-bold text-slate-800 mb-4 flex items-center">
             <FileText size={18} className="mr-2 text-slate-500" />
             Contribution Summary
           </h3>
           <div className="space-y-3">
              <div className="flex justify-between p-3 bg-slate-50 rounded">
                 <span className="text-slate-600">Total Collected</span>
                 <span className="font-bold">{contributions.reduce((a, b) => a + b.amount, 0).toLocaleString()} RWF</span>
              </div>
              <div className="flex justify-between p-3 bg-slate-50 rounded">
                 <span className="text-slate-600">Active Contributors</span>
                 <span className="font-bold">{new Set(contributions.map(c => c.memberId)).size}</span>
              </div>
           </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
           <h3 className="font-bold text-slate-800 mb-4 flex items-center">
             <FileText size={18} className="mr-2 text-slate-500" />
             Loan Portfolio
           </h3>
           <div className="space-y-3">
              <div className="flex justify-between p-3 bg-slate-50 rounded">
                 <span className="text-slate-600">Principal Issued</span>
                 <span className="font-bold">{loans.reduce((a, b) => a + b.principal, 0).toLocaleString()} RWF</span>
              </div>
              <div className="flex justify-between p-3 bg-slate-50 rounded">
                 <span className="text-slate-600">Interest Expected</span>
                 <span className="font-bold text-blue-600">{loans.reduce((a, b) => a + b.totalInterest, 0).toLocaleString()} RWF</span>
              </div>
              <div className="flex justify-between p-3 bg-red-50 rounded border border-red-100">
                 <span className="text-red-700">At Risk (Unpaid)</span>
                 <span className="font-bold text-red-700">{loans.reduce((a, b) => a + b.remainingAmount, 0).toLocaleString()} RWF</span>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}