
import React, { useState } from 'react';
import { useData } from '../context/DataContext';
import { UserRole, LoanStatus, DEFAULT_LOAN_INTEREST } from '../types';
import { Plus, DollarSign, AlertTriangle, User, Globe } from 'lucide-react';

export default function Loans() {
  const { loans, members, currentUser, addLoan, payLoan, translations } = useData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedLoan, setSelectedLoan] = useState<string | null>(null);
  
  // Separate states for Principal and Profit payment
  const [paymentPrincipal, setPaymentPrincipal] = useState<string>('');
  const [paymentProfit, setPaymentProfit] = useState<string>('');

  const [newLoan, setNewLoan] = useState({
    borrowerType: 'MEMBER' as 'MEMBER' | 'EXTERNAL',
    memberId: '',
    borrowerName: '',
    borrowerPhone: '',
    principal: 0,
    dateIssued: new Date().toISOString().split('T')[0],
    dueDate: ''
  });

  const canManage = currentUser?.role !== UserRole.MEMBER;

  const handleCreateLoan = (e: React.FormEvent) => {
    e.preventDefault();
    
    let finalBorrowerName = newLoan.borrowerName;

    if (newLoan.borrowerType === 'MEMBER') {
      const member = members.find(m => m.id === newLoan.memberId);
      if (member) {
        finalBorrowerName = member.fullName;
      } else {
        return; // Validation error
      }
    }

    addLoan({
      memberId: newLoan.borrowerType === 'MEMBER' ? newLoan.memberId : undefined,
      borrowerType: newLoan.borrowerType,
      borrowerName: finalBorrowerName,
      borrowerPhone: newLoan.borrowerType === 'EXTERNAL' ? newLoan.borrowerPhone : undefined,
      principal: newLoan.principal,
      interestRate: DEFAULT_LOAN_INTEREST,
      totalInterest: newLoan.principal * DEFAULT_LOAN_INTEREST,
      totalDue: newLoan.principal * (1 + DEFAULT_LOAN_INTEREST),
      amountPaid: 0,
      interestPaid: 0,
      remainingAmount: newLoan.principal * (1 + DEFAULT_LOAN_INTEREST),
      dateIssued: newLoan.dateIssued,
      dueDate: newLoan.dueDate,
      status: LoanStatus.ACTIVE
    });
    setIsModalOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setNewLoan({
        borrowerType: 'MEMBER',
        memberId: '',
        borrowerName: '',
        borrowerPhone: '',
        principal: 0,
        dateIssued: new Date().toISOString().split('T')[0],
        dueDate: ''
    });
  }

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedLoan) {
      const pPrincipal = parseFloat(paymentPrincipal) || 0;
      const pProfit = parseFloat(paymentProfit) || 0;
      
      if (pPrincipal + pProfit > 0) {
        payLoan(selectedLoan, pPrincipal, pProfit);
        setSelectedLoan(null);
        setPaymentPrincipal('');
        setPaymentProfit('');
      }
    }
  };

  // Filter loans based on role
  const visibleLoans = currentUser?.role === UserRole.MEMBER 
    ? loans.filter(l => l.memberId === currentUser.id)
    : loans;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-800">{translations.loans}</h2>
        {canManage && (
          <button 
            onClick={() => setIsModalOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2"
          >
            <Plus size={20} />
            <span>New Loan</span>
          </button>
        )}
      </div>

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {visibleLoans.map(loan => (
          <div key={loan.id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 relative overflow-hidden">
            <div className={`absolute top-0 right-0 px-3 py-1 text-xs font-bold rounded-bl-lg ${
               loan.status === LoanStatus.PAID ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'
            }`}>
              {loan.status}
            </div>
            
            <div className="flex items-center space-x-3 mb-4">
              <div className={`p-2 rounded-lg ${loan.borrowerType === 'MEMBER' ? 'bg-slate-100' : 'bg-orange-100'}`}>
                {loan.borrowerType === 'MEMBER' ? <User className="text-slate-600" size={24} /> : <Globe className="text-orange-600" size={24} />}
              </div>
              <div>
                 <h3 className="font-semibold text-slate-800">{loan.borrowerName}</h3>
                 <p className="text-xs text-slate-500">Issued: {loan.dateIssued}</p>
                 {loan.borrowerType === 'EXTERNAL' && <p className="text-xs text-orange-600">Non-Member</p>}
              </div>
            </div>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Principal</span>
                <span className="font-medium">{loan.principal.toLocaleString()} RWF</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Total Profit (10%)</span>
                <span className="font-medium">{loan.totalInterest.toLocaleString()} RWF</span>
              </div>
              <div className="h-px bg-slate-100 my-2"></div>
              
              <div className="flex justify-between text-sm">
                 <span className="text-slate-500">Paid Profit</span>
                 <span className="font-bold text-emerald-600">{(loan.interestPaid || 0).toLocaleString()} RWF</span>
              </div>

              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Total Paid</span>
                <span className="font-bold text-blue-600">{loan.amountPaid.toLocaleString()} RWF</span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Remaining Due</span>
                <span className="font-bold text-rose-600">{loan.remainingAmount.toLocaleString()} RWF</span>
              </div>
            </div>

            {loan.remainingAmount > 0 && canManage && (
              <button 
                onClick={() => setSelectedLoan(loan.id)}
                className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 font-medium rounded-lg border border-slate-200 transition-colors"
              >
                Record Payment
              </button>
            )}
          </div>
        ))}
        {visibleLoans.length === 0 && (
          <div className="col-span-full text-center py-12 text-slate-400">
            No loans found.
          </div>
        )}
      </div>

      {/* New Loan Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-6 m-4 overflow-y-auto max-h-[90vh]">
            <h3 className="text-xl font-bold mb-4">Issue New Loan</h3>
            <form onSubmit={handleCreateLoan} className="space-y-4">
               
               {/* Borrower Type Switch */}
               <div className="flex p-1 bg-slate-100 rounded-lg">
                 <button 
                    type="button"
                    onClick={() => setNewLoan({...newLoan, borrowerType: 'MEMBER'})}
                    className={`flex-1 py-1.5 text-sm font-medium rounded-md transition-colors ${
                        newLoan.borrowerType === 'MEMBER' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                    }`}
                 >
                    Member
                 </button>
                 <button 
                    type="button"
                    onClick={() => setNewLoan({...newLoan, borrowerType: 'EXTERNAL'})}
                    className={`flex-1 py-1.5 text-sm font-medium rounded-md transition-colors ${
                        newLoan.borrowerType === 'EXTERNAL' ? 'bg-white text-orange-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                    }`}
                 >
                    Non-Member
                 </button>
               </div>

               {newLoan.borrowerType === 'MEMBER' ? (
                   <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">Select Member</label>
                      <select 
                        required 
                        className="w-full border p-2 rounded" 
                        value={newLoan.memberId} 
                        onChange={e => setNewLoan({...newLoan, memberId: e.target.value})}
                      >
                        <option value="">-- Choose Member --</option>
                        {members.map(m => (
                          <option key={m.id} value={m.id}>{m.fullName}</option>
                        ))}
                      </select>
                   </div>
               ) : (
                   <>
                       <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                          <input 
                            required 
                            type="text"
                            placeholder="External Borrower Name"
                            className="w-full border p-2 rounded" 
                            value={newLoan.borrowerName} 
                            onChange={e => setNewLoan({...newLoan, borrowerName: e.target.value})} 
                          />
                       </div>
                       <div>
                          <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                          <input 
                            required 
                            type="text"
                            placeholder="07..."
                            className="w-full border p-2 rounded" 
                            value={newLoan.borrowerPhone} 
                            onChange={e => setNewLoan({...newLoan, borrowerPhone: e.target.value})} 
                          />
                       </div>
                   </>
               )}

               <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Principal Amount (RWF)</label>
                  <input required type="number" min="1" className="w-full border p-2 rounded" value={newLoan.principal} onChange={e => setNewLoan({...newLoan, principal: parseFloat(e.target.value)})} />
               </div>
               <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Due Date</label>
                  <input required type="date" className="w-full border p-2 rounded" value={newLoan.dueDate} onChange={e => setNewLoan({...newLoan, dueDate: e.target.value})} />
               </div>
               
               <div className="bg-blue-50 p-3 rounded text-sm text-blue-700 flex items-start space-x-2">
                 <AlertTriangle size={16} className="mt-0.5" />
                 <span>Interest (Profit) is automatically calculated at 10% ({newLoan.principal * 0.1} RWF).</span>
               </div>

               <div className="flex justify-end space-x-3 mt-6">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Issue Loan</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {selectedLoan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm p-6 m-4">
            <h3 className="text-xl font-bold mb-4">Record Repayment</h3>
            <form onSubmit={handlePayment} className="space-y-4">
              <div className="bg-slate-50 p-3 rounded text-sm text-slate-600 mb-4">
                  Please split the payment between the Principal amount and the Profit (Interest) amount.
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Principal Payment (RWF)</label>
                  <input 
                    type="number" 
                    min="0"
                    placeholder="0"
                    className="w-full border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none" 
                    value={paymentPrincipal} 
                    onChange={e => setPaymentPrincipal(e.target.value)} 
                  />
              </div>

              <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Profit/Interest Payment (RWF)</label>
                  <input 
                    type="number" 
                    min="0"
                    placeholder="0"
                    className="w-full border p-2 rounded focus:ring-2 focus:ring-emerald-500 outline-none" 
                    value={paymentProfit} 
                    onChange={e => setPaymentProfit(e.target.value)} 
                  />
              </div>

              <div className="flex justify-between items-center bg-slate-100 p-2 rounded font-bold text-slate-700">
                  <span>Total Paying:</span>
                  <span>{((parseFloat(paymentPrincipal)||0) + (parseFloat(paymentProfit)||0)).toLocaleString()} RWF</span>
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <button type="button" onClick={() => setSelectedLoan(null)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-emerald-600 text-white rounded hover:bg-emerald-700">Confirm Payment</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
